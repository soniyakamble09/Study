export const FETCH_ALL = "FETCH_ALL";
export const ADD_TO_CART = "ADD_TO_CART";
export const GET_ALL_CART = "GET_ALL_CART";
export const SET_QUANTITY = "SET_QUANTITY";
export const DELETE_ITEM = "DELETE_ITEM";
export const CAL_TOTAL = "CAL_TOTAL";
export const SORT_PRODUCTS = "SORT_PRODUCTS";
export const FILTER_PRODUCTS = "FILTER_PRODUCTS";