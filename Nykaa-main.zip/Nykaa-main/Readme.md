# Nykaa Clone website
<br>
<br>

This is Landing page
<br/>
<br/>
![image](./readme_images/s6.png)
<br>
<br>


This is makeup-cart  page
<br/>
<br/>
![image](./readme_images/s2.png)
<br>
<br>


This is Login page
<br/>
<br/>
![image](./readme_images/s1.png)
<br>
<br>

This is Shipping page
<br/>
<br/>
![image](./readme_images/s3.png)
<br>
<br>


This is Payment page
<br/>
<br/>
![image](./readme_images/s4.png)
<br>
<br>

This is Payment successful page
<br/>
<br/>
![image](./readme_images/s5.png)
<br>
<br>
<br>
Thank you 😁🙌


