function cart(){
    // Complete to show an alert with your product
    alert("Add your product");
}
