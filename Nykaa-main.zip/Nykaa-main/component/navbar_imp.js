let navbar_imp=()=>{
    return ` 
    <nav id="nav_p">
      <div class="pheading"><a>BEAUTY BONANZA Get Your Daily Dose Of Amazing Deals</a></div>
  
      <div class="a1">        
        <a href="ht" title="" class="">Get App</a>
               
               
                   <a href="hta" title="" class="">Store & Event</a>
               
             
                   <a href="" title="" class="">Gift Crd</a>
               
                
                   <a href="htt" title="" class="">Help</a>
            
   </div>
  </nav> 
  <div class="topnav">
  
  <div class="log">
    <a href="index.html" class="logo" title="logo">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 250">
    <path xmlns="http://www.w3.org/2000/svg" d="M157.9 57.2c5-9.6-11.2-6.9-11.2-6.9-5.8 0-8.4 7-9.6 9l-17.5 34.5c-3.3 5.7-14.2 30.1-17.8 35.5-.3-5.5.1-16.5.2-19.1.7-10.4 1.4-18.3 2.5-27.8.8-7.4 2.4-15.7.9-23.1-1-4.6-2.5-4.9-9.1-5.6-6.9-.7-11.6 9.3-13.9 14-8.4 17.4-17.8 34.4-25.3 52.2-2.2 5.2-4.9 10.4-7.2 15.5-2.7 6.2-5.2 12.3-8.1 18.4-3.1 6.4-12.8 27.4-15.5 34-3 7.2-3.6 13 8.4 12.7 1.9 0 6.1.4 11.3-5.2 4.1-4.4 4.9-8.5 7.3-14.6 8.6-21.6 14.7-35.9 24.1-57.3.9-2.1 3-8.2 5.1-12.9-.1 6.7-1.2 14.7-1.7 20-1.6 19.4-2.7 38.1-4.4 57.3-.2 2.6-.9 5.7.3 8.1 1.2 2.4 4.2 3 6.6 3.3 9.6 1.2 10.6-3.6 13.6-10.2 2.7-5.9 4.3-10.7 6.7-16.7 7.4-18.5 15.2-36.8 23.8-54.8 2.2-4.6 4.4-9.1 6.8-13.6 4.4-8.3 8-16.1 12.8-25.3 3.6-6.6 7.1-14.1 10.9-21.4zm329.5 52.1c-1.1-11.1-16.3-5.5-25.4-3.8-3.4.6-13.9 2.6-26 4.9-.5-12.5-.3-10-.4-17.6-.3-11-.9-19.6-1.5-29.3-.4-6.1-1.3-14.6-12.3-13-12.8 1.8-14.9 8.2-18.3 15.9-8.9 20.1-8.6 20.2-18.7 42.6-.8 1.7-4.5 10.7-5.1 12.5-.4.1-1.2.3-2.2.6-4.1.9-9.1 2-14.6 3.2l.1-.5c1.3-10.2 2.9-20.4 4.3-30.6 1.3-9.3 2.7-24.5 3.8-33.8 1.2-10-10.4-9.8-10.4-9.8-7.1-.4-9.8 1.7-14.3 7.5-7.7 10-17 20.8-25.2 31.8-14.9 19.9-25.8 34.9-39.3 54.9-3.9 5.8-9.9 14.6-15.1 21.5-3.5-6.9-6.5-14.5-9.4-21.5-4.2-10-7.3-16.2-9.3-22.8-1.8-5.8.4-6.6 4.7-9.9 12.4-9.4 26.4-15.9 39.1-24.9 9-6.4 19.8-13.5 28.6-20.1 0 0 5.1-3 7.9-6.8 3.5-4.8-6.4-9.8-6.4-9.8-5.6-.9-8.7.4-12.6 2.2-4 1.8-9.2 5.9-12.6 8.6-7.5 5.8-17 12.7-24.4 18.5-9.1 7.1-15.3 11.5-25.3 17.4l25.4-38c8.3-10.7-13.7-13.7-22.1-2.4-7.8 10.1-13.1 19-19.2 28.2-14.7 21.9-26.8 44.9-38.9 69-4.6 9.2-9.1 18.8-13.3 28.3-2 4.6-7.9 15.2.2 16.3 17.3 2.2 20.1-6 24-15.9 6.4-16.3 8.5-19.3 12.6-29.4 4-9.8 6.9-15.4 11.4-23.8.1-.1 1.4-2.2 1.4-2.2.8 1.7 6.1 19.3 6.8 21.3 3.6 9.5 9.9 31.7 13.5 41.8 2.6 8.4 3.3 10.8 14.6 10.5 5.6-.1 8-2.3 11.7-9.3s19.7-36.8 19.7-36.8c4.8-.8 11.7-2 16.2-2.8.8-.1 2.6-.5 5.1-1 1.7-.2 3.1-.5 4.2-.8.1 0 .1 0 .2-.1 4.4-.9 10-2 16.1-3.2-1.1 5.5-4.5 17.6-5.2 20.7 0 0-7.4 28.8 2.2 30.3 6 .9 9.1-.1 9.1-.1 11.2-1.3 11.4-16.4 11.4-16.4l6.1-39.1c4.4-.9 8.8-1.8 13.1-2.6l-13.2 44.6c-1.9 6.3-3.3 14.4 8 14.4 9.2.5 9.8-5.3 9.8-5.3.2-.9 7.5-24.4 9.3-32.8 1.2-5.4 5.5-19.3 7.2-24.9 4.8-.9 8.4-1.6 10.1-1.9 2-.3 5.9-1 11-1.8-.1 5.2 0 12.4.1 13.4 1.1 15.8-.1 32.2 3.2 47.7.5 2.5 1.5 5.7 4.7 5.7 3.8 0 5-.4 9-.7 11.6-1 9.5-12.7 8.8-20.1-.8-8.2-1.6-15.1-2.7-23.3-.9-6.7-1.5-15.5-1.6-26.1v-.2c19-3.2 39.5-6.7 42.5-7.2 4.8-1.3 8.8-.9 7.8-11.9zm-148.5 21c0 .1-.1.1-.1.2-13.3 2.9-25.8 5.7-32.8 7.3 7-11.7 37.8-54.3 42.5-59.3-2.6 13.2-6.8 37.7-9.6 51.8zm76.8-16.8v.7c-6.4 1.2-12.4 2.4-17.2 3.3 6.1-15.8 12.5-35.2 16.3-45-.3 7.3 1.2 33.8.9 41zM229.2 66.4c2-3.7 6.5-11 .9-13.8-3.3-1.6-7.7-2.6-11.1-.9-2.8 1.5-4.9 4.4-6.3 7.1l-21.4 33.7c-3.5 4.8-6.8 10.8-13.9 11.6-4.7.5-8.1-1.5-8-5.7.1-4.3 2.6-10 4.5-13.7 5.6-10.6 6.3-14.2 11.7-24.7 5.2-10.1-11.8-12.4-16-5.1-3 5.2-8.8 15-10.1 18.3-2.4 6-20.4 34.6-12.6 45.9 10 12.8 36.6-7.4 23 15.9-11 18.7-17.9 29.4-27.5 46.7-2.1 3.7-4.7 7.4-5.4 11.8-1 6.2 7.5 6.1 11.2 5.9 6.5-.5 9.6-3.5 12.2-9.4 1.4-3.1 3.3-6.9 4.7-10 12.6-27.5 26-51.4 42.6-78 7.9-12.6 14.9-23.4 21.5-35.6z" fill="#fc2779"></path></svg>
  </a></div>  
  
  <div id="r_drop_part">
    <div class="drop">
      Categories <i class="fa-solid fa-angle-down"></i>
      <div class="indrop">
        <ul>
          <a href="#">All </a>
        </ul>
        
      </div>
    </div>
    <div class="drop">
      Brands <i class="fa-solid fa-angle-down"></i>
      <div class="indrop">
        <ul>
          <a href="#">POPULAR</a>
        </ul>
        <ul>
          <a href="#">LUXE</a>
        </ul>
        <ul>
          <a href="#">ONLY AT NYKAA</a>
        </ul>
        <ul>
          <a href="#">NEW LAUNCHES</a>
        </ul>
        <ul>
          <a href="#"></a>
        </ul>
        
      </div>
    </div>
    <div class="drop">
      Luxe
   <i class="fa-solid fa-angle-down"></i>
      <div class="indrop">
        <ul>
          <a href="#">Makeup</a>
        </ul>
        <ul>
          <a href="#">Skin</a>
        </ul>
        <ul>
          <a href="#">Fragrance</a>
        </ul>
        <ul>
          <a href="#">Bath and Body </a>
        </ul>
        <ul>
          <a href="#">Gifts</a>
        </ul>
      </div>
    </div>
    
    <div class="drop">
      Nykaa Fashion <i class="fa-solid fa-angle-down"></i>
      <div class="indrop">
        <ul>
          <a href="#">What's New</a>
        </ul>
        <ul>
          <a href="#">Women</a>
        </ul>
        <ul>
          <a href="#">Men</a>
        </ul>
        <ul>
          <a href="#">Kids</a>
        </ul>
        <ul>
          <a href="#">Home</a>
        </ul>
        <ul>
          <a href="#">Tech</a>
        </ul>
        <ul>
          <a href="#">Top brands</a>
        </ul>
      </div>
    </div>
    <div class="drop">
      Beauty Device <i class="fa-solid fa-angle-down"></i>
      <div class="indrop">
        <ul>
          <a href="#">BEAUTY BOOK</a>
        </ul>
        <ul>
          <a href="#">NYKAA TV</a>
        </ul>
        <ul>
          <a href="#">BEAUTY BUYING GUIDES</a>
        </ul>
      </div>
    </div>
    </div>
  
  
  <div class="search-container2">        
    <form>   
      <input type="text2"  id="search" onkeypress="debounce(searchData,2000)" placeholder="Search on Nykaa" name="search" >
    </form>
  </div>
  
  <div class="dropdown">
    <button class="dropbtn"><i class="fa fa-user" style="font-size:24px"></i>
    <a  id="preeti" href="signup.html" >Account</a>
   

      </div>
    </div>
    <div  class="pcart"><i style="font-size:24px" class="fa">&#xf07a;</i></div>
    </div>
  
  </div>
  
  <div>
    
  </div>
  
  
  
  
  <!-- mega menu  -->
  <header id="SP~header">
    <div id="Container_SP">
        <nav id="navbar_SP">
            <ul>
                <li class="nav_menu~SP"> <a href="concealer.html">Makeup</a> 
                    <div class="Mega_Menu_SP">
                        <div class="megamenuitemsp">
                            <p>Face</p>
                            <ul>
                            <li>Face Primer</li> 
                            <li> Concealer</li>
                            <li>Foundation</li>
                            <li>Compact</li>
                            <li>Contour</li> 
                            <li>Loose Powder</li> 
                            <li>Tinted Moisturizer</li>
                            <li>Blush</li> 
                            <li> Bronzer</li>
                            <li>BB & CC Cream</li>
                            <li>Highlighters</li>
                            <li>Setting Spray</li> 
                            <li>Makeup Remover</li> 
                            <li>Sindoor</li>
                        </ul>
                        </div>
                    
                        <div class="megamenuitemsp2">
                            <p>Eyes</p>
                            <ul>
                            <li>Kajal</li> 
                            <li>Eyeliner</li>
                            <li>Mascara</li>
                            <li>Eye Shadow</li>
                            <li>Eye Brow Enhancers</li>
                            <li>Eye Primer</li>
                            <li>False Eyelashes</li>
                            <li>Eye Makeup Remover</li>
                            <li>Under Eye Concealer</li>
                            <li>Contact Lenses</li>
                            </ul>
                            <p>Makeup Kits & Combos</p> 
                        <ul>
                            <li>Makeup Kits</li>
                            <li>Makeup Combos</li>
                            </ul>
                            </div>
                    
                        <div class="megamenuitemsp">
                            <p>Lips</p>
                            <ul>
                            <li>Lipstick</li> 
                            <li>Liquid Lipstick</li>
                            <li>Lip Crayon</li>
                            <li>Lip Gloss</li>
                            <li>Lip Liner</li>
                            <li>Lip Plumper</li>
                            <li>Lip Stain</li>
                        </ul>
                            <p>Nails</p>
                        <ul>
                            <li>Nail Polish</li>
                            <li>Nail Art Kits</li>
                            <li>Nail Care</li>
                            <li>Nail Polish Remover</li>
                        </ul>
                            </div>
                        <div class="megamenuitemsp2">
                            
  
                            <p>Tools & Brushes</p>
                            <ul>
                            <li>Face Brush</li> 
                            <li>Eye Brush</li>
                            <li>Lip Brush</li>
                            <li>Brush Sets</li>
                            <li>Brush Cleaners</li>
                            <li>Sponges & Applicators</li> 
                            <li>Eyelash Curlers</li>
                            <li>Tweezers</li>
                            <li>Sharpeners</li>
                            <li>Mirrors</li>
                            <li>Makeup Pouches</li>
                            <li>Mirrors</li>
                            </ul>
                            
                            <p> Multi-Functional Makeup Palettes</p>
                            </div>
                            <div class="megamenuitemsp">
                            <p>Top Brands</p>
                            <ul>
                            <li>Kay Beauty</li> 
                            <li>Huda Beauty</li>
                            <li>Charlotte Tilbury</li>
                            <li>M.A.C</li>
                            <li>Maybelline New York</li>
                            <li>L'Oreal Professionnel</li>
                            <li>Lakme</li>
                            <li>Nykaa Cosmetics</li>
                            <li>Nyx Pro.Makeup</li>
                            </ul>
                            </div>
                            <div class="megamenuitemsp2">
                                <p>Quick Links</p>
                            <ul>
                            <li>Combos @ Nykaa</li> 
                            <li>New Launches</li>
                            <li>NFBA Nominees 2020</li>
                            <li>Gifts @ Nykaa</li>
                            <li>The Gift Store</li>
                            </ul>
                            <p>Trending Searches</p>
                            <ul>
                                <li>Nude Lipstick</li>
                                <li>Matte Lipstick</li>
                                <li>Red Lipstick</li>
                                <li>Pink Lipstick</li>
                            </ul>
                            </div>
                            </div>
                        </li>
                <li class="nav_menu~SP"> <a href="face_primer.html">Skin</a> 
                    <div class="Mega_Menu_SP">
                        <div class="megamenuitemsp">
                            <p>Moisturizers</p>
                            <ul>
                            <li>Face Moisturizer & Day Cream</li> 
                            <li>Night Cream</li>
                            <li>Face Oils</li>
                            <li>Serums & Essence</li>
                            <li>All Purpose Gels/Creams</li>   
                        </ul>
                        <p>Cleansers</p>
                        <ul>
                        <li>Face Wash</li> 
                        <li>Cleanser</li>
                        <li>Micellar Water</li>
                        <li>Face Wipes</li>
                        <li>Makeup Remover</li> 
                        <li>Scrubs & Exfoliators</li>
                    </ul>
                        </div>
                    
                        <div class="megamenuitemsp2">
                             <p>Trending Searches</p>
                            <ul>
                            <li>Toners Under 1000</li> 
                            <li>Face Wash For Oily Skin</li>
                            <li>Oil Free Face Moisturizers</li>
                            <li>Lip Balm Under 500</li>
                            <li>Vitamin C Serum</li>
                            </ul>
                            <p>Masks</p>
                            <ul>
                            <li>Sheet Masks</li> 
                            <li>Sleeping Masks</li>
                            <li>Masks & Peels</li>
                            <li>Face Packs</li>
                            <li>Face Bleach</li>
                            </ul>
                            <p>Toners</p>
                            <ul>
                            <li> Toners & Mists</li> 
                            <li>Rose Water</li>
                            </ul>
                            </div>
                    
                        <div class="megamenuitemsp">
                            <p>Body Care</p>
                            <ul>
                            <li>Lotions & Creams</li> 
                            <li>Body Butter</li>
                            <li>Massage Oils</li>
                            <li>Shower Gels & Body Wash</li>
                            <li>Soaps</li>
                            <li>Scrubs & Loofahs</li>
                            <li>Bath Salts</li>
                        </ul>
                            <p>Hands & Feet</p>
                        <ul>
                            <li>Hand Creams</li>
                            <li>Foot Creams</li>
                            <li>Hand & Foot Masks</li>
                        </ul>
                            
                            </div>
                        <div class="megamenuitemsp2">
                            <p>Neck Creams</p>
                            <p>Specialised Skincare</p>
                            <ul>
                            <li>Acne Spot Correctors</li> 
                            <li>Nose Strips</li>
                            <li>Facial Peels</li>
                            </ul>
                            
                            <p>Eye Care</p>
                            <ul>
                            <li>Under Eye Cream & Serums</li> 
                            <li>Eye Masks</li>
                            </ul>
                            <p>Lip Care</p>
                            <ul>
                            <li>Lip Balm</li> 
                            <li>Lip Scrubs</li>
                            <li>Lip Masks</li>
                            </ul>
                            <p>Sun Care</p>
                            <ul>
                            <li>Face Sunscreen</li> 
                            <li>Body Sunscreen</li>
                            </ul>
                            </div>
                            <div class="megamenuitemsp">
                            <p>Kits & Combos</p>
                            <ul>
                            <li>Facial Kits</li> 
                            <li>Combos @ Nykaa</li>
                            <li>Gift Sets</li>
                            <li>Skin Tools</li>
                            <li>Face Massagers</li>
                            <li>Cleansing Brushes</li>
                            <li>Blackhead Remover</li>
                            <li>Dermarollers</li>
                            </ul>
                            <p>Skin Tools</p>
                            <ul>
                            <li>Face Massagers</li>
                            <li>Cleansing Brushes</li>
                            <li>Blackhead Remover</li>
                            <li>Dermarollers</li>
  
                            </ul>
                            <p>Skin Supplements</p>
                            <ul>
                            <li>Vitamins & Minerals</li>
                            <li>Ayurvedic Herbs</li>
  
                            </ul>
                            </div>
                            <div class="megamenuitemsp2">
                                <p> Shop By Concern</p>
                            <ul>
                            <li>Acne</li> 
                            <li>Dull Skin</li>
                            <li>Pigmentation</li>
                            <li>Wrinkles & Fine Lines</li>
                            <li>Pores</li>
                            <li>Dark Spots</li>
                            <li>Face Tan</li>
                            <li>Oil Control</li>
                            </ul>
                            <p>New Launches</p>
                            <p>Quick Links</p>
                            <ul>
                            <li>The Gift Store</li> 
                            </ul>
                            </div>
                            </div> 
                </li>
                <li class="nav_menu~SP"> <a href="#">Hair</a> 
                    <div class="Mega_Menu_SP">
                        <div class="megamenuitemsp">
                            <p>Hair Care</p>
                            <ul>
                            <li>Shampoo</li> 
                            <li> Dry Shampoo NEW</li>
                            <li>Conditioner</li>
                            <li>Hair Oil</li>
                            <li>Hair Serum</li> 
                            <li>Hair Creams & Masks</li> 
                            <li>Nutritional Supplements</li>
                        </ul>
                        </div>
                    
                        <div class="megamenuitemsp2">
                            <p>Tools & Accessories</p>
                            <ul>
                            <li>Hair Brushes</li> 
                            <li>Hair Combs</li>
                            <li>Dryers & Stylers</li>
                            <li>Straighteners</li>
                            <li>Rollers & Curlers</li>
                            <li>Hair Extensions</li>
                            <li>Hair Accessories</li>
                            </ul>
                            </div>
                    
                        <div class="megamenuitemsp">
                            <p>Hair Styling</p>
                            <ul>
                            <li>Hair Color</li> 
                            <li>Hair Combs</li>
                            <li>Gels & Waxes</li>
                        </ul>
                            <p>Hair Styling</p>
                        <ul>
                            <li>Straight</li>
                            <li>Curly & Wavy</li>
                        </ul>
                            <p>Professional Brands</p>
                            
                            </div>
                        <div class="megamenuitemsp2">
                            <p>Hairfall & Thinning</p>
                            <ul>
                            <li>Dandruff</li> 
                            <li>Dry & Frizzy Hair</li>
                            <li>Split Ends</li>
                            <li>Straighteners</li>
                            <li>Color Protection</li>
                            </ul>
                            
                            <p> Trending Searches</p>
                            <ul>
                            <li>Hair Growth Oil</li> 
                            <li>Dandruff Shampoo</li>
                            <li>Castor Oil For Hair</li>
                            <li>Sulphate Free Shampoo</li>
                            <li>Hair Straightener Brush</li>
                            </ul>
                            </div>
                            <div class="megamenuitemsp">
                            <p>Top Brands</p>
                            <ul>
                            <li>Nykaa Naturals</li> 
                            <li>L'Oreal Paris</li>
                            <li>Wella Professionals</li>
                            <li>L'Oreal Professionnel</li>
                            <li>BBlunt</li>
                            <li>Herbal Essences</li>
                            <li>Schwarzkopf Professional</li>
                            </ul>
                            </div>
                            <div class="megamenuitemsp2">
                                <p>Top Brands</p>
                            <ul>
                            <li>Nykaa Naturals</li> 
                            <li>L'Oreal Paris</li>
                            <li>Wella Professionals</li>
                            <li>L'Oreal Professionnel</li>
                            <li>BBlunt</li>
                            <li>Herbal Essences</li>
                            <li>Schwarzkopf Professional</li>
                            </ul>
                            </div>
                            </div>
  
                        
                    
                </li>
                <li class="nav_menu~SP"> <a href="#">Appliances</a> 
                    <div class="Mega_Menu_SP">
                        <div class="megamenuitemsp">
                            <p>Hair Styling Tools</p>
                            <ul>
                            <li>Hair Dryers</li> 
                            <li>Straighteners</li>
                            <li>Curling Iron/Stylers</li>
                            <li>Multi Stylers</li>
                        </ul>
                        </div>
                    
                        <div class="megamenuitemsp2">
                            <p>Hair Removal Tools</p>
                            <ul>
                            <li>Epilators</li> 
                            <li>Body Groomers</li>
                            <li>Bikini Trimmers</li>
                            </ul>
                            </div>
                    
                        <div class="megamenuitemsp">
                            <p>Shaving Tools</p>
                            <ul>
                            <li>Shavers</li> 
                            <li>Trimmers</li>
                        </ul>
                            
                            </div>
                        <div class="megamenuitemsp2">
                            <p>Face/Skin Tools</p>
                            <ul>
                            <li>Face Epilator</li> 
                            <li>Dermarollers</li>
                            <li>Cleansing Brushes</li>
                            <li>Acne Removal</li>
                            <li>Massage Tools</li>
                            <li>Massagers</li>
                            <li>Foot Care</li>
                            </ul>
                            </div>
                            <div class="megamenuitemsp">
                            <p>Top Brands</p>
                            <ul>
                            <li>Philips</li> 
                            <li>Alan Truman</li>
                            <li>Dyson</li>
                            <li>VEGA</li>
                            <li>Braun</li>
                            <li>Ikonic Professional</li>
                            <li>Nova</li>
                            <li>Flawless</li>
  
                            </ul>
                            </div>
                            <div class="megamenuitemsp2">
                                <p>Quick Links</p>
                            <ul>
                            <li>Combos @ Nykaa</li> 
                            <li>New Launches</li>
                            <li>NFBA Nominees 2020</li>
                            <li>Gifts @ Nykaa</li>
                            <li>Herbal Hair Care</li>
                            <li>Routine Finder</li>
                            </ul>
                            </div>
                            </div>
                </li>
                <li class="nav_menu~SP"><a href="#">Bath & Body</a>
                    <div class="Mega_Menu_SP">
                        <div class="megamenuitemsp">
                            <p>Bath & Shower</p>
                            <ul>
                            <li>Shower Gels & Body Wash</li> 
                            <li>Body Scrubs & Exfoliants</li>
                            <li>Soaps</li>
                            <li>Bath Salts</li>
                            <li>Bath Accessories</li> 
                        </ul>
                        <p>Body Care</p>
                        <ul>
                            <li>Body Lotions & Moisturizers</li>
                            <li>Deodorants/Roll</li>
                            <li>Body Butters</li>
                            <li>Massage Oils</li>
                            <li>Essential Oils</li>
                            <li>Talcum Powder</li>
                            <li>Intimate Care</li>
                        </ul>
                        </div>
                    
                        <div class="megamenuitemsp2">                               
                            <p>Feminine Hygiene</p>
                            <ul>
                                <li>Sanitary Napkins</li>
                                <li>Menstrual Cups</li>
                                <li>Tampons</li>
                                <li>Pantyliners</li>
                                <li>Intimate Wash</li>
                                <li>Other Period Essentials</li>
                            </ul>
                            <p>Shaving & Hair Removal</p>
                            <ul>
                                <li>Body Razors & Cartridges</li>
                                <li>Face & Eyebrow Razors</li>
                                <li>Wax & Wax Strips</li>
                                <li>Hair Removal Creams</li>
                                <li>Epilators & Bikini Trimmers</li>
                                <li>Pre & Post Wax Essentials</li>
                            </ul>
                            </div>
                    
                        <div class="megamenuitemsp">
                            <p>Men's Grooming</p>
                            <ul>
                                <li>Razors & Catridges</li>
                                <li>Shaving Cream, Foams & Gels</li>
                                <li>Pre & Post Shaves</li>
                                <li>Shavers & Trimmers</li>
                                <li>Beard & Moustache Care</li>
                                <li>Intimate Care</li>
                        </ul>
                            <p>Hands & Feet</p>
                        <ul>
                            <li>Hand Wash</li>
                            <li>Hand Creams & Masks</li>
                            <li>Foot Care</li>
                            <li>Manicure Pedicure Tools & Kits</li>
                        </ul>
                            
                            </div>
                        <div class="megamenuitemsp2">
                            <p>Hygiene Essentials</p>
                            <ul>
                               <li> Face Mask</li>
                               <li> Hand Sanitizer</li>
                               <li> Gloves, PPE & Face Shields</li>
                            </ul>
                            
                            <p>Oral Care</p>
                            <ul>
                               <li> Toothpaste</li>
                               <li> Electric Toothbrush</li>
                               <li> Manual Toothbrush</li>
                               <li> Mouthwash</li>
                               <li> Floss & Tongue Cleaners</li>
                            </ul>
                            </div>
                            <div class="megamenuitemsp">
                            <p>Kits & Combos</p>
                            <ul>
                               <li> Bath & Body Kits</li>
                               <li> Bath & Body Combos</li>
                            </ul>
                            <p>Top Brands</p>
                            <ul>
                               <li> MCaffeine</li>
                               <li> Wanderlust</li>
                               <li> Whisper</li>
                               <li> Gillette</li>
                               <li> Dove</li>
                               <li> Sanfe</li>
                            </ul>
                            </div>
                            <div class="megamenuitemsp2">
  
  
                                <p>Quick Links</p>
                            <ul>
                                <li> @ Nykaa</li>
                                <li>New Launches</li>
                                <li>NFBA Nominees 2020</li>
                                <li>Gifts @ Nykaa</li>
                                <li>Routine Finder</li>
                                <li>The Gift Store</li>
                            </ul>
                            <p>Trending Searches</p>
                            <ul>
                               <li> Body Wash                </li>
                               <li> Body Lotions</li>
                               <li> Face Razors For Women</li>
                               <li> Sanitary Napkins</li>
                               <li> Body Scrubs</li>
                               <li> Deodorants</li>
                            </ul>
                            </div>
                            </div>
                </li>
                <li class="nav_menu~SP"><a href="#">Natural</a>
                    <div class="Mega_Menu_SP">
                        <div class="megamenuitemsp">
                            <p>Skin</p>
                            <ul>
                               <li> Face Wash</li>
                               <li> Cleanser</li>
                               <li> Moisturizer</li>
                               <li> Face Cream</li>
                               <li> Face Mist</li>
                               <li> Facial Kits</li>
                               <li> Toner</li>
                               <li> Face Oils</li>
                               <li> Sunscreen</li>
                               <li> Night Cream</li>
                               <li> Day Cream</li>
                               <li> Under Eye Care</li>
                               <li> Face Bleach</li>
                               <li> Serums</li>
                        </ul>
                        </div>
                    
                        <div class="megamenuitemsp2">
                            <p>Skin</p>
                            <ul>
                                
                               <li> Sheet Masks</li>
                               <li> Masks & Peels</li>
                               <li> Scrubs & Exfoliators</li>
                               <li> Face Tools</li>
                               <li> Face Gel</li>
                               <li> Lip Scrub</li>
                            </ul>
                            <p>Body Care</p>
                            <ul>
                                
                               <li>Shower Gels & Body Wash  </li>
                               <li>Soaps</li>
                               <li>Body Lotions</li>
                               <li>Body Scrubs</li>
                               <li>Bath Salts & Bath Bombs</li>
                               <li>Hands & Feet Care</li>
                               <li>Bath Tools & Accessories</li>
                               <li>Oral Care</li>
                                
                            </ul>
                            </div>
                    
                        <div class="megamenuitemsp">
                            <p>Hair</p>
                            <ul>
                                
                               <li> Shampoo & Cleanser   </li>
                               <li> Conditioner</li>
                               <li> Hair Masks</li>
                               <li> Hair Oil</li>
                               <li> Hair Serum</li>
                               <li> Hair Color</li>
                               <li> Tools & Accessories</li>
                                </ul>
                                <p>Hair</p>
                                <ul>
                                <li>Aromatherapy  </li>
                                <li>Massage Oils</li>
                                <li>Carrier Oils</li>
                                <li>Essential Oils</li>
                                <li>Candles</li>
                                <li>Diffuser</li>
                                <li>Incense Sticks</li>
                        </ul>
                            
                            </div>
                        <div class="megamenuitemsp2">
                            <p>Makeup</p>
                            <ul>
                                
                                <li>Lipstick </li>
                                <li>Kajal</li>
                                <li>Eyeliner</li>
                                <li>Mascara</li>
                                <li>Nail Polish</li>
                                <li>Lip Balm & Gloss</li>
                                <li>Foundation & Concealer</li>
                                <li>Blush & Highlighter</li>
                                <li>Makeup Remover</li>
                                <li>Tools & Brushes</li>
  
                            </ul>
                            
                            <p> Trending Searches</p>
                            <ul>
                               <li> Tea Tree Oil  </li>
                               <li> Eucalyptus Oil</li>
                               <li> Rosemary Oil</li>
                               <li> Jojoba Oil</li>
                               <li> Peppermint Oil</li>
                            </ul>
                            </div>
                            <div class="megamenuitemsp">
                            <p>Top Brands</p>
                            <ul>
                                <li>Biotique</li>
                                <li>Lotus Herbals</li>
                                <li>The Body Shop</li>
                                <li>Nykaa Naturals</li>
                                <li>Kama Ayurveda</li>
                                <li>Forest Essentials</li>
                                <li>Khadi Natural</li>
                                <li>Himalaya</li>
                                <li>VLCC</li>
                            </ul>
                            <p>Baby Care</p>
                            <p>Types of Skin</p>
                                
                                <ul>
                               <li> Dry Skin </li>
                               <li> Normal Skin</li>
                               <li> Oily Skin</li>
                               <li> Combination Skin</li>
                            </ul>
                            </div>
                            <div class="megamenuitemsp2">
                                <p>Shop By Concern</p>
                            <ul>
                                
                                <li>Tan Removal</li>
                                <li>Pigmentation</li>
                                <li>Acne Treatment</li>
                                <li>Skin Lightening</li>
                                <li>Anti Aging</li>
                                <li>Dark Circles</li>
                                <li>Hairfall</li>
                                <li>Dandruff</li>
                                <li>Dry & Frizzy Hair</li>
                                </ul>
                                <p>QUICK LINKS</p>
  
                                <ul>
                                <li>New Launches</li>
                                <li>Combos @ Nykaa</li>
                                <li>Gifts @ Nykaa</li>
                                <li>The Safe (And Clean) Beauty Edit</li>
                            </ul>
                            </div>
                            </div>
                </li>
                <li class="nav_menu~SP"><a href="#">Mom & Baby</a>
                    <div class="Mega_Menu_SP">
                        <div class="megamenuitemsp">
                            <p>Baby Care</p>
                            <ul>
                                
                               <li> Body Wash & Soaps </li>
                               <li> Baby Oil</li>
                               <li> Hair Oil</li>
                               <li> Lotions & Creams</li>
                               <li> Baby Powder</li>
                               <li> Shampoo & Conditioner</li>
                               <li> Sunscreen</li>
                               <li> Wipes & Buds</li>
                               <li> Teeth & Dental Care</li>
                               <li> Rash Cream</li>
                               <li> Diapers</li>
                               <li> Diaper Accessories</li>
                               <li> Bath Accessories</li>
                               <li> Baby Grooming</li>
                               <li> Baby Bedding</li>
                        </ul>
                        </div>
                    
                        <div class="megamenuitemsp2">
                            <p> Kids Care</p>
                            <ul>
                               
                               <li> Nutritional Supplement</li>
                               <li> Body Wash & Soaps</li>
                               <li> Lotions & Creams</li>
                               <li> Hair Care</li>
                               <li> Sunscreen</li>
                               <li> Dental Care</li>
                               <li> Kids Makeup</li>
                            </ul>
                            </div>
                    
                        <div class="megamenuitemsp">
                            <p>Maternity Care</p>
                            <ul>
                               <li> Stretch Mark Creams & Oils    </li>
                               <li> Breast Firming Gels & Creams</li>
                               <li> Nipple Creams</li>
                               <li> Nutritional Supplements</li>
                               <li> Maternity Pillows</li>
                        </ul>
                            </div>
                        <div class="megamenuitemsp2">
                            <p>Nursing & Feeding</p>
                            <ul>    
                                <li>Feeding Bottle & Nipples        </li>
                                <li>Teethers & Soothers</li>
                                <li>Breast Pumps</li>
                                <li>Breast Pads</li>
                                <li>Cleaning & Feeding Accessories</li>
                                <li>Bibs</li>
                                <li>Sippers & Cups</li>
                            </ul>
                            </div>
                            <div class="megamenuitemsp">
                            <p>Health & Safety</p>
                            <ul>
                                <li>Nose & Ear Care</li>
                                <li>Gripe Water & Tummy Roll On</li>
                                <li>Detergents & Cleansers</li>
                                <li>Handwash & Sanitizer</li>
                                <li>Mosquito Repellent</li>
                            </ul>
                                <p>Maternity Wear</p>
                                <ul>
                                <li>Maternity Bra</li>
                                <li>Maternity Dress</li>
                                <li>Maternity Tops</li>
                            </ul>
                            </div>
                            <div class="megamenuitemsp2">
                                <p>Baby Toys</p>
                                <p>Gift Sets</p>
                                <p>Shop By Concerns</p>
  
                            <ul>
                                   <li> Baby Dry Skin</li>
                                   <li> Cracked Nipple Cream</li>
                                   <li> Scalp Treatment</li>
                                   <li> Coconut Oil</li>
                                   <li> Almond Oil</li>
                                   <li> Heat Rash</li>
                                   <li> Body Toning & Firming</li>
                                   <li> Baby Skin Concerns</li>
                                    
                            </ul>
                            <p>Combos @ Nykaa</p>
  
                            </div>
                            </div>
                </li>
                <li class="nav_menu~SP"><a href="#">Health & Wellness</a>
                    <div class="Mega_Menu_SP">
                        <div class="megamenuitemsp">
                            <p>Health Supplements</p>
                            <ul>
                                
                                <li>Multivitamins</li>
                                <li>Calcium & Vitamin D</li>
                                <li>Magnesium & Zinc</li>
                                <li>Omega 3 & Fish Oil</li>
                                <li>Immunity Boosters & Vitamin C</li>
                                <li>Other Supplements</li>
                            </ul>
                                <p>Beauty Supplements</p>
                                <ul>
                                <li>Collagen (Skin)</li>
                                <li>Biotin (Hair)</li>
                                <li>Vitamin E (Skin)</li>
                                <li>Glutathione (Skin)</li>
                                <li>Other Beauty Supplements</li>
                        </ul>
                        </div>
                    
                        <div class="megamenuitemsp2">
                            <p>Sports Nutrition</p>
                            <ul>
                                
                               <li> Whey Protein                 </li>
                               <li> Plant Protein</li>
                               <li> BCAA & Other Muscle Support</li>
                               <li> Protein & Energy Bars</li>
                               <li> Protein Snacks</li>
                               </ul>
                               <p> Weight Management</p>
                               <ul>
                               <li> Weight Gain</li>
                               <li> Apple Cider Vinegar</li>
                               <li> Green Tea</li>
                               <li> Green Coffee</li>
                               <li> Fat Burner</li>
                               <li> Slimming Shakes & Juices</li>
                               <li> Sugar Substitutes</li>
                            </ul>
                            </div>
                    
                        <div class="megamenuitemsp">
                            <p>Health Foods</p>
                            <ul>
                            
  
                                   <li> Honey                       </li>
                                   <li> Dry Fruits, Nuts & Berries</li>
                                   <li> Edible Seeds</li>
                                   <li> Oils & Ghee</li>
                                   <li> Black Tea & Coffee</li>
                                   <li> Herbal Teas</li>
                                   <li> Health Drinks</li>
                                   <li> Breakfast Cereals</li>
                                   <li> Other Health Foods</li>
                                </ul>
                                   <p> Wellness Equipment</p>
                                   <ul>
                                   <li> Weighing Scales</li>
                                   <li> Fitness</li>
                                   <li> Face Steamers</li>
                        </ul>
                            
                            
                            </div>
                        <div class="megamenuitemsp2">
                            <p>Supports & Braces</p>
                            <p>Pain Relief</p>
  
                            <ul>
                                <li> Muscles & Joints </li>
                               <li> Ortho Oils</li>
                               <li> Period Cramps</li>
                               <li> Cough & Cold</li>
                            </ul>
                            
                            <p>Sexual Wellness</p>
                            <ul>
                                <li> Condoms</li>
                                <li> Lubricants</li>
                                <li> Sexual Enhancers</li>
                            </ul>
                            <p> Medical Devices</p>
  
                            <ul>
                               <li> Oximeters</li>
                            </ul>
                            </div>
                            <div class="megamenuitemsp">
                            <p>Ayurveda & Herbs</p>
                            <ul>
                                
                               <li> Ashwagandha</li>
                               <li> Neem (Blood Purifier)</li>
                               <li> Amla (Immunity, Skin)</li>
                               <li> Aloe Vera (Liver, Skin)</li>
                               <li> Milk Thistle (Liver)</li>
                               <li> Wheatgrass (Detox)</li>
                               <li> Tulsi</li>
                               <li> Giloy & Guduchi (Immunity)</li>
                               <li> Turmeric (Anti Inflamatory)</li>
                               <li> Spirulina & Moringa</li>
                               <li> Chyavanprash</li>
                               <li> Shilajit</li>
                               <li> Other Herbal Supplements</li>
                            </ul>
                            </div>
                            <div class="megamenuitemsp2">
                                <p>Shop By Concern</p>
                            <ul>
                               <li> Diabetes</li>
                               <li> Digestion (Gut Health)</li>
                               <li> Organs - Liver, Heart, Kidney</li>
                               <li> Safety & First Aid</li>
                               <li> Weakness & Vitality</li>
                               <li> Kids Nutrition</li>
                               <li> Mental Wellness</li>
                               <li> Blood Pressure</li>
                               <li> Hormonal Balance</li>
                               <li> Calm & Sleep</li>
                            </ul>
                            </div>
                            </div>
                </li>
                <li class="nav_menu~SP"><a href="#">Men</a>
                    <div class="Mega_Menu_SP">
                        <div class="megamenuitemsp">
                            <p>Shaving</p>
                            <ul>
                                
                               <li> Razors & Cartridges    </li>
                               <li> Shavers</li>
                               <li> Trimmers</li>
                               <li> Shaving Creams</li>
                               <li> Shaving Foams</li>
                               <li> Shaving Gels</li>
                               <li> Pre & Post Shaves</li>
                               <li> Aftershave Lotion</li>
                               <li> Shaving Brushes</li>
                        </ul>
                        </div>
                    
                        <div class="megamenuitemsp2">
                            <p>Beard Care</p>
                            <ul>
                                        <li> Beard Oil     </li>
                                        <li>Beard Butter</li>
                                        <li>Beard Softener</li>
                                        <li>Beard Wash</li>
                                        <li>Beard Wax</li>
                                        <li>Moustache Oil</li>
                                        <li>Beard Comb</li>
                                        <li>Moustache Wax</li>
                                        <li>Beard Kits</li>
                                        <li>Beard Gel</li>
                                        <li>Beard Balm</li>
                                        <li>Beard Cream</li>
                                        <li>Beard Serum</li>
                                        <li>Beard Mist</li>
                                        <li>Beard Colour</li>
                                        <li>Beard Shampoo</li>
                            </ul>
                            </div>
                    
                        <div class="megamenuitemsp">
                            <p>Hair Care</p>
                            <ul>
                                
                                <li>Shampoo</li>
                                <li>Conditioner</li>
                                <li>Hair Styling</li>
                                <li>Hair Color</li>
                                <li>Hair Oils</li>
                                <li>Professional Products</li>
                                
                        </ul>
                            <p>Skin Care</p>
                        <ul>
                            <li>Face Wash</li>
                                <li>Moisturizers</li>
                                <li>Sunscreen</li>
                                <li>Masks & Peels</li>
                                <li>Scrubs & Exfoliators</li>
                                <li>Fairness</li>
                        </ul>
                            
                            </div>
                        <div class="megamenuitemsp2">
                            <p>Bath & Body</p>
                            <ul>
                                
                               <li>Bath/Shower Gels </li>
                               <li>Soaps</li>
                               <li>Body Scrubs</li>
                               <li>Talc</li>
                               <li>Dental Care</li>
                               <li>Body Lotions</li>
                               <li>Intimate Care</li>
                               
                                
                            </ul>
                            
                            <p> Grooming Kits</p>
                            <p> Fragrance</p>
  
                            <ul>
                                <li>Deodorants/Roll Ons</li>
                                <li>Colognes & Perfumes (EDT & EDP)</li>
                                <li>Luxe Fragrances</li>
                            </ul>
                            </div>
                            <div class="megamenuitemsp">
                            <p>Shop By Concern</p>
                            <ul>
                                
                                <li>Anti Dandruff </li>
                                <li>Anti Hairfall</li>
                                <li>Scalp Treatment</li>
                                <li>Anti Acne</li>
                                <li>Anti Ageing</li>
                                
                            </ul>
                            <p>Wellness</p>
                            <ul>
                                <li>Sexual Wellness</li>
                                <li>Health Supplements</li>
                                <li>Weight Management</li>
                                <li>Sports Nutrition</li>
                            </ul>
                            </div>
                            <div class="megamenuitemsp2">
                                <p>Top Brands</p>
                            <ul>
                               <li> Top Brands</li>
                               <li> Beardo</li>
                               <li> Gilette</li>
                               <li> Livon</li>
                               <li> Nivea</li>
                               <li> Park Avenue</li>
                               
                            </ul>
                            <p>Quick Links</p>
                            <ul>
                                <li> Combos @ Nykaa</li>
                                <li> New Launches</li>
                                <li> Gifts @ Nykaa</li>
                                <li> Routine Finder</li>
                                <li> The Gift Store</li>
                            </ul>
                            </div>
                            </div>
                </li>
                <li class="nav_menu~SP"><a href="#">Frangrance</a>
                    <div class="Mega_Menu_SP">
                        <div class="megamenuitemsp">
                            <p>Womens Fragrance</p>
                            <ul>
                                
                                <li>Perfumes (EDT / EDP)   </li>
                                <li>Body Mists / Sprays</li>
                                <li>Deodorants / Roll-Ons</li>
                        </ul>
                        <p>Mens Fragrance</p>
                        <ul>
                            <li>Perfumes (EDT / EDP)</li>
                            <li>Body Mists / Sprays</li>
                            <li>Deodorants / Roll-Ons</li>
                            <li>Colognes & After Shaves</li>
                        </ul>
                        </div>
                    
                        <div class="megamenuitemsp2">
                            <p>Giftsets & Combos</p>
                            <p>Shop By Fragrance Family</p>
                            <ul>
                            
                               <li> Earthy & Woody   </li>
                               <li> Floral</li>
                               <li> Fresh & Aquatic</li>
                               <li> Spicy & Warm</li>
                               <li> Oud Collection</li>
                               <li> Fruity</li>
                            </ul>
                            </div>
                    
                        <div class="megamenuitemsp">
                            <p>The Parcos Store</p>
                            <p>Candles</p>
                            
                            
                            </div>
                        <div class="megamenuitemsp2">
                            <p>Top Brands</p>
                            <ul>
                            
  
                                    <li>Nykaa Cosmetics    </li>
                                    <li>Masaba By Nykaa</li>
                                    <li>Dior</li>
                                    <li>Gucci</li>
                                    <li>Calvin Klein</li>
                                    <li>Davidoff</li>
                                    <li>Hermes</li>
                                    <li>Bvlgari</li>
                                    <li>Versace</li>
                                    <li>Skinn By Titan</li>
                                    <li>Paco Rabanne</li>
                                    <li>Giorgio Armani</li>
                            </ul>
                            </div>
                            <div class="megamenuitemsp">
                            <p>PREMIUM AND DESIGNER BRANDS</p>
                            <ul>
                            
  
                                    <li>Explore All </li>
                                    <li>Dior</li>
                                    <li>Hermès</li>
                                    <li>Jo Malone London</li>
                                    <li>Guerlain</li>
                                    <li>BVLGARI</li>
                                    <li>Salvatore Ferragamo</li>
                                    <li>Calvin Klein</li>
                                    <li>Giorgio Armani</li>
                                    <li>Davidoff</li>
                                    <li>Paco Rabanne</li>
                                    <li>Carolina Herrera</li>
                                    <li>Yves Saint Laurent</li>
                                    <li>Elie Saab</li>
                            </ul>
                            </div>
                            <div class="megamenuitemsp2">
                               
                            <ul>
                                <li>Dolce & Gabbana</li>
                                <li>Narciso Rodrigue</li>
                                <li>Hugo Boss</li>
                                <li>Montblanc</li>
                            
                            </ul>
                            <p>Quick Links</p>
                            <ul>
                                <li>Combos @ Nykaa</li>
                                <li>New Launches</li>
                                <li>NFBA Nominees 2020</li>
                                <li>Help Me Choose - Fragrance Finder</li>
                                <li>Gifts @ Nykaa</li>
                                <li>The Gift Store</li>
                            </ul>
                            </div>
                            </div>
                </li>
                <li class="nav_menu~SP"><a href="#">Pop Ups</a>
                    <div class="Mega_Menu_SP">
                        <div class="megamenuitemsp">
                            <p>Bras</p>
                            <ul>
                                
                                <li>T-Shirt Bra</li>
                                <li>Padded Bra</li>
                                <li>Non-Padded Bra</li>
                                <li>Wireless Bra</li>
                                <li>Underwired Bra</li>
                                <li>Strapless Bra</li>
                                <li>Bralette</li>
                                <li>Push-Up Bra</li>
                                <li>Beginners Bra</li>
                                <li>Maternity Bra</li>
                               
                        </ul>
                        <p>Underwear</p>
                        <ul>
                            <li>Briefs</li>
                            <li>Bikini</li>
                            <li>Boyshorts</li>
                            <li>Seamless Panties</li>
                            <li>Shorties</li>
                            <li>Period Panties</li>
                        </ul>
                        </div>
                    
                        <div class="megamenuitemsp2">
                            <p>Sleep & Lounge</p>
                            <ul>
                            
  
                                    <li>Sets        </li>
                                    <li>Nightdress</li>
                                    <li>Babydolls</li>
                                    <li>Pajamas</li>
                                    <li>Wraps</li>
                                    <li>Shorts</li>
                                    <li>Loungewear</li>
                                    
                            </ul>
                            <p>The Activewear</p>
                            <ul>
                                <li>Sports Bras</li>
                                    <li>Leggings</li>
                                    <li>Tanks & Tees</li>
                                    <li>Shorts</li>
                                    <li>Jackets & Hoodies</li>
                                    <li>Swimwear</li>
                            </ul>
                            </div>
                    
                        <div class="megamenuitemsp">
                            <p>Bags</p>
                            <ul>
                                
                                <li>Sling Bags</li>
                                <li>Handbags</li>
                                <li>Wallets</li>
                                <li>Tote Bags</li>
                                <li>Backpacks & Duffel Bags</li>
                                <li>Satchels</li>
                                <li>Clutches</li>
                                <li>Laptop Bags & Sleeves</li>
                                <li>Makeup Pouches & Vanity Kits</li>
                                <li>Batuas & Potlis</li>
                                
                        </ul>
                            <p>Shapewear</p>
                        <ul>
                            <li>Tummy & Waist Cinchers</li>
                                <li>Saree Shapewear</li>
                                <li>Body Shapers</li>
                                <li>Thigh Shapers</li>
                                <li>Shaping Briefs</li>
                        </ul>
                            
                            </div>
                        <div class="megamenuitemsp2">
                            <p>Footwear</p>
                            <ul>
                                
                               <li> Sports Shoes & Sneakers  </li>
                               <li> Sandals</li>
                               <li> Heels</li>
                               <li> Flats</li>
                               <li> Flip Flops</li>
                               <li> Wedges</li>
                               <li> Boots</li>
                               <li> Jutttis</li>
                               <li> Kolhapuris</li>
                               <li> Stilletos</li>
                               <li> Loafers</li>
                               
                            </ul>
                            
                            <p>Jewellery</p>
                            <ul>
                                <li> Earrings</li>
                                <li> Necklaces</li>
                                <li> Maang Tikka</li>
                                <li> Bracelets & Bangles</li>
                                <li> Rings</li>
                            </ul>
                            </div>
                            <div class="megamenuitemsp">
                            <p>Gadgets And Tech</p>
                            <ul>
                                
                                <li>Headphones</li>
                                <li>Speakers</li>
                                <li>Smart Watches & Activity Trackers</li>
                                <li>Power Banks</li>
                                <li>Cables & Chargers</li>
                                <li>Cameras & Accessories</li>
                                <li>Smart Home Devices</li>
                                <li>Cases And Covers</li>
                                <li>Computer Peripherals</li>
                                
                            </ul>
                                <p>Watches</p>
                                <p>Sunglasses</p>
                                <p>Home</p>
                                <p>Kids</p>
                            </div>
                            <div class="megamenuitemsp2">
                                <p>Featured Brands</p>
                            <ul>
                                <li>NYKD By Nykaa</li>
                                <li>Twenty Dresses</li>
                                <li>RSVP</li>
                                <li>Pipa Bella</li>
                                <li>Kica</li>
                                <li>Puma</li>
                                <li>Titan</li>
                                <li>Eridani</li>
                                <li>Lavie</li>
                                <li>Giva</li>
                                <li>IYKYK</li>
                                <li>Twig And Twine</li>
                                <li>Gajra Gang</li>
                                <li>Likha</li>
                                <li>Azai By Nykaa Fashion</li>
                                <li>Gloot</li>
                            </ul>
                            </div>
                            </div>
                </li>
            </ul>
        </nav>
        <div class="SP_logo">
            <div class="SP_btnofr"><a id="offer_s"  href="offer.html">OFFER</a></div>
        </div>
    </div>
  </header>
  
  `
}

export default navbar_imp