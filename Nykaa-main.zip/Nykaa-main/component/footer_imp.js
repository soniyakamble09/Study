let footer_imp=()=>{
    return `  <div id="emailSendbtnSP">
    <h3>Thank you for Subscribing</h3>
</div>
    <div id="end">
        <div>
          <div>
            <form >
              <h5>GET SPECIAL DISCOUNT ON YOUR INBOX</h5>
            <input id="mail" type="text" placeholder="Your Mail">
            <input type="submit" value="send" id="submitmail" placeholder="Send">
            </form>
          </div>
          <div>
            <h5>EXPERIENCE THE NYKAA MOBILE APP</h5>
            <img id="logo" onclick="window.location.href='https://play.google.com/store/apps/details?id=com.fsn.nykaa&hl=en_IN&shortlink=60aeffe1&pid=Android&c=Android&is_retargeting=true'" src="https://th.bing.com/th/id/R.198e2192907ddc5fc0c48b934c9a8b29?rik=M1bMqZ2ToGyd4Q&riu=http%3a%2f%2fwww.occc.net%2fportals%2f0%2fLibrary%2fLogos%2fgoogle-play-badge_scaled.png&ehk=7DKSGXdhkc18gDRGF%2frLxD6NdovQ1Xv7b0wlrFp%2fg%2fI%3d&risl=&pid=ImgRaw&r=0" alt="fasf">
            <img id="logo" onclick="window.location.href='https://apps.apple.com/in/app/nykaa-makeup-beauty-shopping/id1022363908?c=iOS&is_retargeting=true&pid=Footer&shortlink=134e9662'" src="https://th.bing.com/th/id/R.198e2192907ddc5fc0c48b934c9a8b29?rik=M1bMqZ2ToGyd4Q&riu=http%3a%2f%2fwww.occc.net%2fportals%2f0%2fLibrary%2fLogos%2fgoogle-play-badge_scaled.png&ehk=7DKSGXdhkc18gDRGF%2frLxD6NdovQ1Xv7b0wlrFp%2fg%2fI%3d&risl=&pid=ImgRaw&r=0" alt="fasf">
          </div>
          <div>
            <h5>FOR ANY HELP YOU MAY CALL US AT</h5>
            <h5>1800-267-4444</h5>
            <h5>(Monday to Saturday, 8AM to 10PM and Sunday, 10AM to 7PM)</h5>
          </div>
        </div>
    </div>
    <div class="wholefooter">
        <div class="footer-container">
          <div class="footer">
            <div class="footer-heading footer-1">
              <h3>
                <img
                  src="https://tse4.mm.bing.net/th?id=OIP.kACH6frMPM7GVrB3oodlxwAAAA&pid=Api&P=0&w=229&h=165"
                  style="width: 100px; height: 50px"
                />
              </h3>
              <a href="#">WHO ARE WE?</a>
              <a href="#">CAREERS</a>
              <a href="#">AUTHENTICITY</a>
              <a href="#">PRESS</a>
              <a href="#">TESTIMONIALS</a>
              <a href="#">NYKAA CSR</a>
              <a href="#">RESPONSIBLE DISCLOSURE</a>
              <a href="#">INVESTOR RELATIONS</a>
            </div>
            <div class="footer-heading footer-2">
              <h3 id="white">HELP</h3>
              <a href="#">CONTACT US</a>
              <a href="#">FREQUENTLY ASKED QUESTIONS</a>
              <a href="#">STORE LOCATER</a>
              <a href="#">CANCELLATION & RETURN</a>
              <a href="#">SHIPPING & DELIVERY</a>
              <a href="#">SELL ON NYKAA</a>
            </div>
            <div class="footer-heading footer-3">
              <h3 id="white">INSPIRE ME</h3>
              <a href="#">BEAUTY BOOK</a>
              <a href="#">NYKAA TV</a>
              <a href="#">NYKAA NETWORK</a>
              <a href="#">BUYING GUIDES</a>
            </div>
            <div class="footer-heading footer-3">
              <h3 id="white">QUICKS LINKS</h3>
              <a href="#">OFFER ZONE</a>
              <a href="#">NEW LAUNCHES</a>
              <a href="#">NYKAA MAN</a>
              <a href="#">NYKAA FASHION</a>
              <a href="#">NYKAA PRO</a>
              <a href="#">NYKAA FEMINA</a>
              <a href="#">SITEMAP</a>
            </div>
            <div class="footer-heading footer-3">
              <h3 id="white">TOP CATEGORIES</h3>
              <a href="#">MAKEUP</a>
              <a href="#">SKIN</a>
              <a href="#">HAIR</a>
              <a href="#">PERSONAL CARES</a>
              <a href="#">APPLIANCES</a>
              <a href="#">MOM AND BABY</a>
              <a href="#">WELLNESS</a>
              <a href="#">FRAGRANCES</a>
              <a href="#">NATURAL</a>
              <a href="#">LUXE</a>
            </div>
          </div>
        </div>
        <div id="lovediv">

            <img class="footlogo" src="https://adn-static2.nykaa.com/media/wysiwyg/2021/Free-shipping.svg" >
          <div class="some">
             
            <h4>EASY RETURNS</h4>
            <hr>
            <li>15 Days Easy Return</li>
            <li>For Most Products</li>
  
          </div>
          <img class="footlogo" src="https://adn-static2.nykaa.com/media/wysiwyg/2021/return_accepted.svg" >
          <div class="some">
              
              <h4>EASY RETURNS</h4>
              <hr>
              <li>15 Days Easy Return</li>
              <li>For Most Products</li>
  
          </div>
          <img class="footlogo" src="https://adn-static2.nykaa.com/media/wysiwyg/2021/Authenticity.svg" >
          <div class="some">
            <h4>EASY RETURNS</h4>
            <hr>
            <li>15 Days Easy Return</li>
            <li>For Most Products</li>
  
          </div>
          <img class="footlogo" src="https://adn-static2.nykaa.com/media/wysiwyg/2021/Brands.svg" >
          <div class="some">
            <h4>EASY RETURNS</h4>
            <hr>
            <li>15 Days Easy Return</li>
            <li>For Most Products</li>
          </div>
          <div class="footer-email-form">
              <h2 class="MEDIA_SP">SHOW US SOME LOVE ❤ ON SOCIAL MEDIA</h2>
              <div class="media">
                <img src="https://images-static.naikaa.com/media/wysiwyg/2021/icons/ic_social-instagram-filled.svg" alt="">
                <img src="https://images-static.naikaa.com/media/wysiwyg/2021/icons/ic_social-facebook-filled.svg" alt="">
                <img src="https://images-static.naikaa.com/media/wysiwyg/2021/icons/ic_social-youtube-filled.svg" alt="">
                <img src="https://images-static.naikaa.com/media/wysiwyg/2021/icons/ic_social-youtube-filled.svg" alt="">
                <img src="https://images-static.naikaa.com/media/wysiwyg/2021/icons/ic_social-pinterest-filled.svg" alt="">
              </div>
                  </div>
  
              </div>
          </div>
        <div class="sfooter">
          <div>
            <p>TERMS & CONDITIONS</p>
            <p>SHIPPING POLICY</p>
            <p>CANCELLATION POLICY</p>
            <p>PRIVACY POLICY</p>
        </div>
        <div><p>© 2021 Nykaa E-Retail Pvt. Ltd. All Rights Reserved</p></div>

       </div>
      </div>
    </div>`
}

export default footer_imp